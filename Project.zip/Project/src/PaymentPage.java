import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;

public class PaymentPage {

	private JFrame frame;
	private JTable tblTotalCost;
	private JTextField txtNameInput;
	private JTextField textField;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextField txtExpDateInput;
	private JTextField txtCVVInput;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaymentPage window = new PaymentPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PaymentPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCartMenu = new JLabel("Cart");
		lblCartMenu.setBounds(221, 23, 45, 13);
		frame.getContentPane().add(lblCartMenu);
		
		tblTotalCost = new JTable();
		tblTotalCost.setBounds(126, 46, 221, 77);
		frame.getContentPane().add(tblTotalCost);
		
		JLabel lblNameUser = new JLabel("Name");
		lblNameUser.setBounds(122, 138, 45, 13);
		frame.getContentPane().add(lblNameUser);
		
		txtNameInput = new JTextField();
		txtNameInput.setBounds(251, 135, 96, 19);
		frame.getContentPane().add(txtNameInput);
		txtNameInput.setColumns(10);
		
		JLabel lblCreditCardNum = new JLabel("Credit Card Number");
		lblCreditCardNum.setBounds(122, 161, 96, 13);
		frame.getContentPane().add(lblCreditCardNum);
		
		textField = new JTextField();
		textField.setBounds(251, 158, 96, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		lblNewLabel = new JLabel("Expiration Date");
		lblNewLabel.setBounds(122, 184, 81, 13);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("CVV Code");
		lblNewLabel_1.setBounds(122, 207, 64, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		txtExpDateInput = new JTextField();
		txtExpDateInput.setBounds(251, 181, 96, 19);
		frame.getContentPane().add(txtExpDateInput);
		txtExpDateInput.setColumns(10);
		
		txtCVVInput = new JTextField();
		txtCVVInput.setBounds(251, 204, 96, 19);
		frame.getContentPane().add(txtCVVInput);
		txtCVVInput.setColumns(10);
		
		JButton btnPayNow = new JButton("Pay Now");
		btnPayNow.setBounds(176, 230, 85, 21);
		frame.getContentPane().add(btnPayNow);
	}
}
