import java.awt.EventQueue;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class CoffeeMenuPage {

    private JFrame frame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CoffeeMenuPage window = new CoffeeMenuPage();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public CoffeeMenuPage() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JLabel lblCoffeeMenu = new JLabel("Coffee");
        lblCoffeeMenu.setBounds(194, 37, 45, 13);
        frame.getContentPane().add(lblCoffeeMenu);
        
        JButton btnAddToCart = new JButton("Add All To Cart");
        btnAddToCart.setBounds(265, 33, 103, 21);
        frame.getContentPane().add(btnAddToCart);


        JLabel imgEspresso = new JLabel("Espresso Image");
        imgEspresso.setBounds(66, 75, 45, 13);
        frame.getContentPane().add(imgEspresso);

        JCheckBox chkEspressoItem = new JCheckBox("");
        chkEspressoItem.setBounds(145, 75, 32, 21);
        frame.getContentPane().add(chkEspressoItem);

        JLabel lblEspressoPrice = new JLabel("Espresso - $2.50");
        lblEspressoPrice.setBounds(194, 75, 100, 13);
        frame.getContentPane().add(lblEspressoPrice);

        JLabel lblEspressoInfo = new JLabel("A bold, concentrated shot of rich coffee.");
        lblEspressoInfo.setBounds(194, 87, 250, 32);
        frame.getContentPane().add(lblEspressoInfo);

        JButton btnSingleEspresso = new JButton("Order");
        btnSingleEspresso.setBounds(297, 71, 85, 21);
        frame.getContentPane().add(btnSingleEspresso);


        JLabel imgCappuccino = new JLabel("Cappuccino Image");
        imgCappuccino.setBounds(66, 140, 45, 13);
        frame.getContentPane().add(imgCappuccino);

        JCheckBox chkCappuccinoItem = new JCheckBox("");
        chkCappuccinoItem.setBounds(145, 140, 32, 21);
        frame.getContentPane().add(chkCappuccinoItem);

        JLabel lblCappuccinoPrice = new JLabel("Cappuccino - $4.00");
        lblCappuccinoPrice.setBounds(194, 129, 100, 13);
        frame.getContentPane().add(lblCappuccinoPrice);

        JLabel lblCappuccinoInfo = new JLabel("Espresso with steamed milk and foam.");
        lblCappuccinoInfo.setBounds(194, 152, 250, 32);
        frame.getContentPane().add(lblCappuccinoInfo);

        JButton btnSingleCappuccino = new JButton("Order");
        btnSingleCappuccino.setBounds(297, 125, 85, 21);
        frame.getContentPane().add(btnSingleCappuccino);


        JLabel imgLatte = new JLabel("Latte Image");
        imgLatte.setBounds(66, 213, 45, 13);
        frame.getContentPane().add(imgLatte);

        JCheckBox chkLatteItem = new JCheckBox("");
        chkLatteItem.setBounds(145, 213, 32, 21);
        frame.getContentPane().add(chkLatteItem);

        JLabel lblLattePrice = new JLabel("Latte - $4.75");
        lblLattePrice.setBounds(194, 194, 100, 13);
        frame.getContentPane().add(lblLattePrice);

        JLabel lblLatteInfo = new JLabel("Espresso with steamed milk and a light layer of foam.");
        lblLatteInfo.setBounds(194, 213, 250, 32);
        frame.getContentPane().add(lblLatteInfo);

        JButton btnSingleLatte = new JButton("Order");
        btnSingleLatte.setBounds(297, 190, 85, 21);
        frame.getContentPane().add(btnSingleLatte);


        JLabel imgAmericano = new JLabel("Americano Image");
        imgAmericano.setBounds(66, 306, 45, 13);
        frame.getContentPane().add(imgAmericano);

        JCheckBox chkAmericanoItem = new JCheckBox("");
        chkAmericanoItem.setBounds(145, 306, 32, 21);
        frame.getContentPane().add(chkAmericanoItem);

        JLabel lblAmericanoPrice = new JLabel("Americano - $3.50");
        lblAmericanoPrice.setBounds(181, 273, 100, 13);
        frame.getContentPane().add(lblAmericanoPrice);

        JLabel lblAmericanoInfo = new JLabel("Espresso with hot water, creating a similar strength to drip coffee.");
        lblAmericanoInfo.setBounds(181, 296, 250, 32);
        frame.getContentPane().add(lblAmericanoInfo);

        JButton btnSingleAmericano = new JButton("Order");
        btnSingleAmericano.setBounds(297, 269, 85, 21);
        frame.getContentPane().add(btnSingleAmericano);


        JLabel imgFlatWhite = new JLabel("Flat White Image");
        imgFlatWhite.setBounds(66, 379, 45, 13);
        frame.getContentPane().add(imgFlatWhite);

        JCheckBox chkFlatWhiteItem = new JCheckBox("");
        chkFlatWhiteItem.setBounds(145, 379, 32, 21);
        frame.getContentPane().add(chkFlatWhiteItem);

        JLabel lblFlatWhitePrice = new JLabel("Flat White - $4.00");
        lblFlatWhitePrice.setBounds(181, 363, 100, 13);
        frame.getContentPane().add(lblFlatWhitePrice);

        JLabel lblFlatWhiteInfo = new JLabel("Espresso with velvety microfoam milk.");
        lblFlatWhiteInfo.setBounds(181, 386, 250, 32);
        frame.getContentPane().add(lblFlatWhiteInfo);

        JButton btnSingleFlatWhite = new JButton("Order");
        btnSingleFlatWhite.setBounds(297, 359, 85, 21);
        frame.getContentPane().add(btnSingleFlatWhite);
    }
}
