import java.awt.EventQueue;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class PastryMenuPage {

    private JFrame frame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    PastryMenuPage window = new PastryMenuPage();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public PastryMenuPage() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblPastriesMenu = new JLabel("Pastries");
        lblPastriesMenu.setBounds(194, 22, 60, 20);
        frame.getContentPane().add(lblPastriesMenu);

        JButton btnAddToCart = new JButton("Add All To Cart");
        btnAddToCart.setBounds(263, 18, 130, 25);
        frame.getContentPane().add(btnAddToCart);

        JLabel imgCroissant = new JLabel("Croissant Image");
        imgCroissant.setBounds(66, 45, 74, 60); // Placeholder for the image
        frame.getContentPane().add(imgCroissant);

        JCheckBox chkCroissantItem = new JCheckBox("");
        chkCroissantItem.setBounds(145, 70, 32, 21);
        frame.getContentPane().add(chkCroissantItem);

        JLabel lblCroissantPrice = new JLabel("Croissant - $3.50");
        lblCroissantPrice.setBounds(194, 65, 120, 20);
        frame.getContentPane().add(lblCroissantPrice);

        JLabel lblCroissantInfo = new JLabel("A flaky, buttery pastry, perfect for breakfast.");
        lblCroissantInfo.setBounds(194, 85, 250, 20);
        frame.getContentPane().add(lblCroissantInfo);

        JButton btnSingleCroissant = new JButton("Order");
        btnSingleCroissant.setBounds(308, 63, 85, 25);
        frame.getContentPane().add(btnSingleCroissant);

        JLabel imgMuffin = new JLabel("Muffin Image");
        imgMuffin.setBounds(66, 120, 74, 60); // Placeholder for the image
        frame.getContentPane().add(imgMuffin);

        JCheckBox chkMuffinItem = new JCheckBox("");
        chkMuffinItem.setBounds(145, 145, 32, 21);
        frame.getContentPane().add(chkMuffinItem);

        JLabel lblMuffinPrice = new JLabel("Muffin - $2.75");
        lblMuffinPrice.setBounds(194, 140, 120, 20);
        frame.getContentPane().add(lblMuffinPrice);

        JLabel lblMuffinInfo = new JLabel("A moist, delicious muffin with various flavors.");
        lblMuffinInfo.setBounds(194, 160, 250, 20);
        frame.getContentPane().add(lblMuffinInfo);

        JButton btnSingleMuffin = new JButton("Order");
        btnSingleMuffin.setBounds(308, 138, 85, 25);
        frame.getContentPane().add(btnSingleMuffin);

        JLabel imgCinnamonRoll = new JLabel("Cinnamon Roll Image");
        imgCinnamonRoll.setBounds(66, 195, 74, 60); // Placeholder for the image
        frame.getContentPane().add(imgCinnamonRoll);

        JCheckBox chkCinnamonRollItem = new JCheckBox("");
        chkCinnamonRollItem.setBounds(145, 220, 32, 21);
        frame.getContentPane().add(chkCinnamonRollItem);

        JLabel lblCinnamonRollPrice = new JLabel("Cinnamon Roll - $2.75");
        lblCinnamonRollPrice.setBounds(194, 215, 140, 20);
        frame.getContentPane().add(lblCinnamonRollPrice);

        JLabel lblCinnamonRollInfo = new JLabel("A sweet roll with cinnamon and sugar topping.");
        lblCinnamonRollInfo.setBounds(194, 235, 250, 20);
        frame.getContentPane().add(lblCinnamonRollInfo);

        JButton btnSingleCinnamonRoll = new JButton("Order");
        btnSingleCinnamonRoll.setBounds(308, 213, 85, 25);
        frame.getContentPane().add(btnSingleCinnamonRoll);

        JLabel imgAlmondBiscotti = new JLabel("Almond Biscotti Image");
        imgAlmondBiscotti.setBounds(66, 270, 74, 60); // Placeholder for the image
        frame.getContentPane().add(imgAlmondBiscotti);

        JCheckBox chkAlmondBiscottiItem = new JCheckBox("");
        chkAlmondBiscottiItem.setBounds(145, 295, 32, 21);
        frame.getContentPane().add(chkAlmondBiscottiItem);

        JLabel lblAlmondBiscottiPrice = new JLabel("Almond Biscotti - $2.00");
        lblAlmondBiscottiPrice.setBounds(194, 290, 140, 20);
        frame.getContentPane().add(lblAlmondBiscottiPrice);

        JLabel lblAlmondBiscottiInfo = new JLabel("Crispy and crunchy almond cookie, perfect with coffee.");
        lblAlmondBiscottiInfo.setBounds(194, 310, 300, 20);
        frame.getContentPane().add(lblAlmondBiscottiInfo);

        JButton btnSingleAlmondBiscotti = new JButton("Order");
        btnSingleAlmondBiscotti.setBounds(308, 288, 85, 25);
        frame.getContentPane().add(btnSingleAlmondBiscotti);

        JLabel imgLemonTart = new JLabel("Lemon Tart Image");
        imgLemonTart.setBounds(66, 345, 74, 60); // Placeholder for the image
        frame.getContentPane().add(imgLemonTart);

        JCheckBox chkLemonTartItem = new JCheckBox("");
        chkLemonTartItem.setBounds(145, 370, 32, 21);
        frame.getContentPane().add(chkLemonTartItem);

        JLabel lblLemonTartPrice = new JLabel("Lemon Tart - $4.00");
        lblLemonTartPrice.setBounds(194, 365, 120, 20);
        frame.getContentPane().add(lblLemonTartPrice);

        JLabel lblLemonTartInfo = new JLabel("A sweet and tangy tart with a buttery crust.");
        lblLemonTartInfo.setBounds(194, 385, 250, 20);
        frame.getContentPane().add(lblLemonTartInfo);

        JButton btnSingleLemonTart = new JButton("Order");
        btnSingleLemonTart.setBounds(297, 363, 85, 25);
        frame.getContentPane().add(btnSingleLemonTart);
    }
}
