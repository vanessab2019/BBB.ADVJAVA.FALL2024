import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class LoginPage {

	private JFrame frame;
	private JTextField txtLoginUser;
	private JTextField txtLoginPass;
	private JButton btnSignUp;
	private JLabel lblSignUpEmail;
	private JLabel lblLoginUser;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage window = new LoginPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setBounds(164, 32, 74, 13);
		frame.getContentPane().add(lblLogin);
		
		txtLoginPass = new JTextField();
		txtLoginPass.setBounds(194, 59, 96, 21);
		frame.getContentPane().add(txtLoginPass);
		txtLoginPass.setColumns(10);
		
		txtLoginUser = new JTextField();
		txtLoginUser.setBounds(194, 109, 96, 21);
		frame.getContentPane().add(txtLoginUser);
		txtLoginUser.setColumns(10);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(153, 157, 85, 21);
		frame.getContentPane().add(btnLogin);
		
		btnSignUp = new JButton("Sign Up");
		btnSignUp.setBounds(153, 198, 85, 21);
		frame.getContentPane().add(btnSignUp);
		
		lblSignUpEmail = new JLabel("Username");
		lblSignUpEmail.setBounds(116, 63, 68, 13);
		frame.getContentPane().add(lblSignUpEmail);
		
		lblLoginUser = new JLabel("Password");
		lblLoginUser.setBounds(116, 113, 45, 13);
		frame.getContentPane().add(lblLoginUser);
	}

}
