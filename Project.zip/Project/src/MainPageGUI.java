import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTable;

public class MainPageGUI {

    private JFrame frame;
    private JTable tblCoffeeMenu;
    private JTable tblPastryMenu;
    private JTable tblSnackMenu;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainPageGUI window = new MainPageGUI();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public MainPageGUI() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        // Logo Image
        JLabel imgLogoCover = new JLabel("Logo Image");
        imgLogoCover.setBounds(26, 36, 150, 50);
        frame.getContentPane().add(imgLogoCover);

        // Coffee Menu Title
        JLabel lblCoffeeTitle = new JLabel("Coffee Variant");
        lblCoffeeTitle.setBounds(200, 155, 150, 30);
        frame.getContentPane().add(lblCoffeeTitle);

        // Pastry Menu Title
        JLabel lblPastryTitle = new JLabel("Pastries");
        lblPastryTitle.setBounds(200, 285, 150, 30);
        frame.getContentPane().add(lblPastryTitle);

        // Snack Menu Title
        JLabel lblSnackTitle = new JLabel("Snack Variant");
        lblSnackTitle.setBounds(200, 435, 150, 30);
        frame.getContentPane().add(lblSnackTitle);

        // Order Buttons
        JButton btnCoffeeOrder = new JButton("Order Now");
        btnCoffeeOrder.setBounds(388, 155, 120, 30);
        frame.getContentPane().add(btnCoffeeOrder);

        JButton btnPastryOrder = new JButton("Order Now");
        btnPastryOrder.setBounds(388, 285, 120, 30);
        frame.getContentPane().add(btnPastryOrder);

        JButton btnSnackOrder = new JButton("Order Now");
        btnSnackOrder.setBounds(388, 435, 120, 30);
        frame.getContentPane().add(btnSnackOrder);

        // Cart and Logout Buttons
        JButton btnCart = new JButton("Cart");
        btnCart.setBounds(414, 79, 80, 30);
        frame.getContentPane().add(btnCart);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBounds(414, 30, 80, 30);
        frame.getContentPane().add(btnLogout);
        
        // Cover image for coffee
        JLabel imgCoffeeCover = new JLabel("Coffee Image");
        imgCoffeeCover.setBounds(200, 36, 150, 50);
        frame.getContentPane().add(imgCoffeeCover);
        
        tblCoffeeMenu = new JTable();
        tblCoffeeMenu.setBounds(243, 195, 124, 92);
        frame.getContentPane().add(tblCoffeeMenu);
        
        tblPastryMenu = new JTable();
        tblPastryMenu.setBounds(243, 325, 124, 92);
        frame.getContentPane().add(tblPastryMenu);
        
        tblSnackMenu = new JTable();
        tblSnackMenu.setBounds(243, 461, 124, 92);
        frame.getContentPane().add(tblSnackMenu);
    }
}
