import java.awt.EventQueue;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class SnackMenuPage {

    private JFrame frame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SnackMenuPage window = new SnackMenuPage();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public SnackMenuPage() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblSnackMenu = new JLabel("Snack");
        lblSnackMenu.setBounds(200, 20, 100, 30);
        frame.getContentPane().add(lblSnackMenu);

        JButton btnAddToCart = new JButton("Add All To Cart");
        btnAddToCart.setBounds(255, 20, 150, 30);
        frame.getContentPane().add(btnAddToCart);

        // Veggie Platter
        JLabel imgVeggiePlatter = new JLabel("Veggie Platter Image");
        imgVeggiePlatter.setBounds(50, 70, 92, 50);
        frame.getContentPane().add(imgVeggiePlatter);

        JCheckBox chkVeggiePlatterItem = new JCheckBox("");
        chkVeggiePlatterItem.setBounds(167, 70, 20, 20);
        frame.getContentPane().add(chkVeggiePlatterItem);

        JLabel lblVeggiePlatterPrice = new JLabel("Veggie Platter - $5.50");
        lblVeggiePlatterPrice.setBounds(240, 70, 150, 20);
        frame.getContentPane().add(lblVeggiePlatterPrice);

        JLabel lblVeggiePlatterInfo = new JLabel("Fresh vegetables served with dip.");
        lblVeggiePlatterInfo.setBounds(240, 90, 250, 20);
        frame.getContentPane().add(lblVeggiePlatterInfo);

        JButton btnSingleVeggiePlatter = new JButton("Order");
        btnSingleVeggiePlatter.setBounds(400, 70, 80, 25);
        frame.getContentPane().add(btnSingleVeggiePlatter);

        // Cheese & Crackers
        JLabel imgCheeseCrackers = new JLabel("Cheese & Crackers Image");
        imgCheeseCrackers.setBounds(50, 130, 92, 50);
        frame.getContentPane().add(imgCheeseCrackers);

        JCheckBox chkCheeseCrackersItem = new JCheckBox("");
        chkCheeseCrackersItem.setBounds(167, 150, 20, 20);
        frame.getContentPane().add(chkCheeseCrackersItem);

        JLabel lblCheeseCrackersPrice = new JLabel("Cheese & Crackers - $4.00");
        lblCheeseCrackersPrice.setBounds(240, 130, 132, 20);
        frame.getContentPane().add(lblCheeseCrackersPrice);

        JLabel lblCheeseCrackersInfo = new JLabel("Delicious cheese served with crackers.");
        lblCheeseCrackersInfo.setBounds(240, 150, 250, 20);
        frame.getContentPane().add(lblCheeseCrackersInfo);

        JButton btnSingleCheeseCrackers = new JButton("Order");
        btnSingleCheeseCrackers.setBounds(400, 130, 80, 25);
        frame.getContentPane().add(btnSingleCheeseCrackers);

        // Fruit Parfait
        JLabel imgFruitParfait = new JLabel("Fruit Parfait Image");
        imgFruitParfait.setBounds(50, 190, 80, 50);
        frame.getContentPane().add(imgFruitParfait);

        JCheckBox chkFruitParfaitItem = new JCheckBox("");
        chkFruitParfaitItem.setBounds(167, 210, 20, 20);
        frame.getContentPane().add(chkFruitParfaitItem);

        JLabel lblFruitParfaitPrice = new JLabel("Fruit Parfait - $4.75");
        lblFruitParfaitPrice.setBounds(240, 190, 122, 20);
        frame.getContentPane().add(lblFruitParfaitPrice);

        JLabel lblFruitParfaitInfo = new JLabel("Layers of yogurt, fruit, and granola.");
        lblFruitParfaitInfo.setBounds(240, 210, 250, 20);
        frame.getContentPane().add(lblFruitParfaitInfo);

        JButton btnSingleFruitParfait = new JButton("Order");
        btnSingleFruitParfait.setBounds(400, 190, 80, 25);
        frame.getContentPane().add(btnSingleFruitParfait);

        // Granola Bar
        JLabel imgGranolaBar = new JLabel("Granola Bar Image");
        imgGranolaBar.setBounds(50, 250, 92, 50);
        frame.getContentPane().add(imgGranolaBar);

        JCheckBox chkGranolaBarItem = new JCheckBox("");
        chkGranolaBarItem.setBounds(167, 270, 20, 20);
        frame.getContentPane().add(chkGranolaBarItem);

        JLabel lblGranolaBarPrice = new JLabel("Granola Bar - $2.50");
        lblGranolaBarPrice.setBounds(240, 250, 122, 20);
        frame.getContentPane().add(lblGranolaBarPrice);

        JLabel lblGranolaBarInfo = new JLabel("A healthy snack bar full of oats and honey.");
        lblGranolaBarInfo.setBounds(240, 270, 250, 20);
        frame.getContentPane().add(lblGranolaBarInfo);

        JButton btnSingleGranolaBar = new JButton("Order");
        btnSingleGranolaBar.setBounds(400, 250, 80, 25);
        frame.getContentPane().add(btnSingleGranolaBar);

        // Avocado Toast
        JLabel imgAvocadoToast = new JLabel("Avocado Toast Image");
        imgAvocadoToast.setBounds(50, 310, 92, 50);
        frame.getContentPane().add(imgAvocadoToast);

        JCheckBox chkAvocadoToastItem = new JCheckBox("");
        chkAvocadoToastItem.setBounds(167, 330, 20, 20);
        frame.getContentPane().add(chkAvocadoToastItem);

        JLabel lblAvocadoToastPrice = new JLabel("Avocado Toast - $6.00");
        lblAvocadoToastPrice.setBounds(226, 310, 141, 20);
        frame.getContentPane().add(lblAvocadoToastPrice);

        JLabel lblAvocadoToastInfo = new JLabel("Toasted bread topped with smashed avocado.");
        lblAvocadoToastInfo.setBounds(226, 340, 250, 20);
        frame.getContentPane().add(lblAvocadoToastInfo);

        JButton btnSingleAvocadoToast = new JButton("Order");
        btnSingleAvocadoToast.setBounds(400, 310, 80, 25);
        frame.getContentPane().add(btnSingleAvocadoToast);
    }
}
