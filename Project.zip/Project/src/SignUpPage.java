import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SignUpPage {

	private JFrame frame;
	private JTextField txtSignUpEmail;
	private JTextField txtSignUpPass;
	private JTextField txtSignUpUsername;
	private JTextField txtSignUpVerif;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUpPage window = new SignUpPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SignUpPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSignUp = new JLabel("Sign Up Here");
		lblSignUp.setBounds(169, 29, 83, 13);
		frame.getContentPane().add(lblSignUp);
		
		txtSignUpEmail = new JTextField();
		txtSignUpEmail.setBounds(216, 59, 96, 19);
		frame.getContentPane().add(txtSignUpEmail);
		txtSignUpEmail.setColumns(10);
		
		JLabel lblLoginUser = new JLabel("Username");
		lblLoginUser.setBounds(114, 93, 62, 13);
		frame.getContentPane().add(lblLoginUser);
		
		JLabel lblLoginPass = new JLabel("Password");
		lblLoginPass.setBounds(114, 122, 45, 13);
		frame.getContentPane().add(lblLoginPass);
		
		txtSignUpPass = new JTextField();
		txtSignUpPass.setBounds(216, 119, 96, 19);
		frame.getContentPane().add(txtSignUpPass);
		txtSignUpPass.setColumns(10);
		
		JButton btnLogin = new JButton("Sign Up");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnLogin.setBounds(184, 208, 85, 21);
		frame.getContentPane().add(btnLogin);
		
		JLabel lblSignUpEmail = new JLabel("Email");
		lblSignUpEmail.setBounds(114, 62, 45, 13);
		frame.getContentPane().add(lblSignUpEmail);
		
		txtSignUpUsername = new JTextField();
		txtSignUpUsername.setBounds(216, 90, 96, 19);
		frame.getContentPane().add(txtSignUpUsername);
		txtSignUpUsername.setColumns(10);
		
		JLabel lblConfirmPass = new JLabel("Confirm Password");
		lblConfirmPass.setBounds(114, 158, 83, 13);
		frame.getContentPane().add(lblConfirmPass);
		
		txtSignUpVerif = new JTextField();
		txtSignUpVerif.setBounds(216, 155, 96, 19);
		frame.getContentPane().add(txtSignUpVerif);
		txtSignUpVerif.setColumns(10);
	}
}
